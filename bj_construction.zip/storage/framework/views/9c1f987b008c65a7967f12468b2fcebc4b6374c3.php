

<?php $__env->startSection('nav_title','Client Update'); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Client Update</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item">Client</li>
              <li class="breadcrumb-item active">Update</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <?php if(session()->has('success')): ?>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-5">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Success!</h5>
                <?php echo e(session()->get('success')); ?>

              </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(session()->has('danger')): ?>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-5">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Error!</h5>
                <?php echo e(session()->get('danger')); ?>

              </div>
        </div>
    </div>
    <?php endif; ?>
    <?php $__errorArgs = ['site_visit_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-5">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Error!</h5>
                <?php echo e($message); ?>

              </div>
        </div>
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<!-- Main content -->

<div class="container">
    <form action="<?php echo e(route('admin.visiting.update',$visiting->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Reference No</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['reference_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="reference_no" placeholder="Reference No" name="reference_no" value="<?php echo e($visiting->reference_no); ?>" required>
                </div>
                <div class="form-group">
                    <label>First Name</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="first_name" placeholder="First Name" name="first_name" value="<?php echo e($visiting->first_name); ?>" required>
                </div>
                <div class="form-group">
                    <label>Contact No</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contact_no" placeholder="Contact No" name="contact_no" value="<?php echo e($visiting->contact_no); ?>" required autofocus>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['user_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="user_address" placeholder="Address" name="user_address" value="<?php echo e($visiting->user_address); ?>" autocomplete="false">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Last Name" name="last_name" value="<?php echo e($visiting->last_name); ?>" required autofocus>
                </div>
                <div class="form-group">
                    <label>Contact Home</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['contact_home'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contact_home" placeholder="Contact No Home" name="contact_home" value="<?php echo e($visiting->contact_home); ?>" required autofocus>
                </div>
                <div class="form-group">
                    <label>Near City</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['near_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="near_city" placeholder="Near City" name="near_city" value="<?php echo e($visiting->near_city); ?>" required autofocus>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Email Address" name="email" value="<?php echo e($visiting->email); ?>" autocomplete="false">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Service Category</label>
                    <select class="form-control" name="service_category">
                        <option value="toilet_single_job" <?php echo e($visiting->service_category == 'toilet_single_job' ? 'selected' : ''); ?>>Toilet Single Job</option>
                        <option value="toilet_full_job" <?php echo e($visiting->service_category == 'toilet_full_job' ? 'selected' : ''); ?>>Toilet Full Job</option>
                        <option value="waste_water_single_job" <?php echo e($visiting->service_category == 'waste_water_single_job' ? 'selected' : ''); ?>>Waste Water Single Job</option>
                        <option value="waste_water_full_job" <?php echo e($visiting->service_category == 'waste_water_full_job' ? 'selected' : ''); ?>>Waste Water Full Job</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Water Level</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['water_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="water_level" placeholder="Water Level" name="water_level" value="<?php echo e($visiting->water_level); ?>" required autofocus>
                </div>
                <div class="form-group">
                    <label>Site Visit</label>
                    <select class="form-control" name="site_visit" id="site_visit" onchange="visibility()">
                        <option value="yes" <?php echo e($visiting->site_visit == 'yes' ? 'selected' : ''); ?>>Yes</option>
                        <option value="no" <?php echo e($visiting->site_visit == 'no' ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>
                <div class="form-group" style="display: none" id="site_visit_date_id">
                    <label>Site Visit Date</label>
                    <input type="date" class="form-control <?php $__errorArgs = ['site_visit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="site_visit_date" name="site_visit_date" autocomplete="false">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Status</label>
                    <select class="form-control" name="status" id="status">
                        <option value="0" <?php echo e($visiting->status == '0' ? 'selected' : ''); ?>>Visit Pending</option>
                        <option value="1" <?php echo e($visiting->status == '1' ? 'selected' : ''); ?>>Visited</option>
                        <option value="2" <?php echo e($visiting->status == '2' ? 'selected' : ''); ?>>Job Done</option>
                    </select>
                </div>
                <div class="form-group" style="display: none" id="site_visit_fee">
                    <label>Site Visit Fee</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['site_visit_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="site_visit_fee" placeholder="Site visiting fee" name="site_visit_fee" value="<?php echo e($visiting->site_visit_fee); ?>" autocomplete="false">
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for=""></label>
            <button type="submit" class="form-control btn-primary">Update</button>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_js'); ?>
    <script>
        function visibility(){
            if (document.getElementById("site_visit").value === 'yes') {
                document.getElementById("site_visit_date_id").style.display = "block";
                document.getElementById("site_visit_fee").style.display = "block";
            }else{
                document.getElementById("site_visit_date_id").style.display = "none";
                document.getElementById("site_visit_fee").style.display = "none";
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bj_construction\resources\views/admin/visiting/edit.blade.php ENDPATH**/ ?>